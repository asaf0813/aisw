package model1.dao;

public class BoardDAO {

}
