package model1.vo;

public class Board {

}
